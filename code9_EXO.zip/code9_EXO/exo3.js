		

	alert(" Pwogram sa la pou l met yon itilizate nan fòma tit. \nSa vle di premye lèt chak mo dwe majiskil, epi lòt yo miniskil")
	 
	let nonItilizate =prompt(" Antre non w, svp")
	     
	nonItilizate =nonItilizate.toLowerCase().split(" ")
	   
	   let tabFomaTit=[];
	    nonItilizate.forEach(element => {
	         let idxNon=element.charAt(0).toUpperCase();
	         let remp=element.replace(element.charAt(0),idxNon);
	          tabFomaTit.push(remp);

	    });
	    
	    console.log(tabFomaTit.join(" "))

	