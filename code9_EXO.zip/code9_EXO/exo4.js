		
		alert("Pwogram sa  2 nonb a ak b. Anndan yon entèval (x, y) enklizif. \n Li afiche tout nonb ak total nonb ki respekte kondisyon sa yo anndan entèval la");
		let a = prompt("Antre a ");

		let b= prompt("Antre b ");
		let x = prompt("Antre x");

		let y= prompt("Antre y ");


		
	
	    let compteurMiltipA = 0;
	    let tabloMiltipA = [];
	    let tabloMiltipB = [];

		   for(let m=x; m<=y;m++ ){
			   	if(m % a == 0 && m % b != 0 ){
			   		compteurMiltipA ++;
			   		tabloMiltipA.push(m)
			   	}
		   }
			
		console.log("Miltip a, men ki pa miltip b : " + tabloMiltipA + 
			" \n epi Kantite a se : " + compteurMiltipA)


		let compteurMiltipB =0 ;
		for(let m=x; m<=y;m++ ){
		   	if( m % b == 0  && m % a != 0){
		   		compteurMiltipB ++;
		   		tabloMiltipB.push(m)
		   	}
	   }

		   console.log("Miltip b, men ki pa miltip  : " + tabloMiltipB + 
			" \n epi Kantite a se : " + compteurMiltipB)



		let compteurMiltipAB =0 ;
		let tabloMiltipAB =[];
			for(let m=x; m<=y;m++ ){
			   	if( m % b == 0  && m % a == 0){
			   		compteurMiltipAB ++;
			   		tabloMiltipAB.push(m)
			   	}
		   }

		   console.log("Miltip a,b : " + tabloMiltipAB + 
			" \n epi Kantite a se : " + compteurMiltipAB)



		let compteurMiltipC =0 ;
		let tabloMiltipC =[];
			for(let m=x; m<=y;m++ ){
			   	if( m % b != 0  && m % a != 0){
			   		compteurMiltipC ++;
			   		tabloMiltipC.push(m)
			   	}
		   }

		   console.log("Ki pa miltip ni a ni b : " + tabloMiltipC + 
			" \n epi Kantite a se : " + compteurMiltipC)


