	
	alert("Pwogram sa afiche OK si antye N a PA divizib pa 4, afichye NOK nan lòt ka")
		let N ;
	
			
		N = prompt("Antre antye N ou an");

		if(N %4 ==0){
			alert("OK")
		}
		else
			alert("NOK")


