    
alert("Pwogram sa la pou \n Kalkile pwodwi, total chak dijit ki konpoze chak nonb .")
     nonb=prompt("Antre nonb lan, svp")
     nonb=nonb.split(" ");
     console.log(nonb);

    let multiply=1;
    for(let i=0; i<nonb.length; i++){
        let sum=0;
        for(let j=0; j<nonb[i].length; j++){
            let num=parseInt(nonb[i][j]);
            sum+=num;  

        }
      multiply*=sum;
    }

    console.log(multiply);