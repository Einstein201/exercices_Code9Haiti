		
let nom ="Ayiti se yon BEL PEYI"
   
   
   let tab=nom.toLowerCase().split(" ")
   console.log(tab)

   let tab1=[]
     tab.forEach(element => {
     	if(charAt(1)){
         let idxlet=element.toUpperCase();
     }
         let remp=element.replace(element.charAt(1),idxlet);
         tab1.push(remp);
     });
    console.log(tab1.join(' '))

		



// 		//**************************       Exercice3    ******************

// 		let nonItilizate ;

// 		//nonItilizate = prompt("Antre non ou, tanpri");

	


		
		



		//**************************       Exercice5    ******************