	
	alert("Pwogram sa fe  total tout dijit yo ki nan adrès IP a.\n Apresa li  miltiplye l pa premye dijit ki nan adrès IP a.");

	let adresIp=prompt("Antre adress IP ou an")
	let adresIp1=adresIp.replaceAll(".", "");
	let arr =[];
	let reziltaIp =0;

		for( let i=0; i<adresIp1.length; i++){
			 arr.push(parseInt(adresIp1[i]));
			 reziltaIp += (arr[i]);	 
		}

		reziltaIp *= arr[0];
       	console.log( "Donk pòt ki ouvri a se: " + reziltaIp)
